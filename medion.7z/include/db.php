<?php 
    define('DB_HOST', 'medion.mcdir.ru');
    define('DB_USER', 'a355412_mysql');
    define('DB_PASSWORD', '98f05Pyb29');
    define('DB_NAME', 'a355412_mysql');

    $mysql = new mysqli(DB_HOST,
    DB_USER,
    DB_PASSWORD,
    DB_NAME);
    if($mysql->connect_errno) exit('Ошибка подключения к ДБ');
    $mysql->set_charset('utf8');
    $mysql->close();

    $link = mysqli_connect('medion.mcdir.ru', 'a355412_mysql', '98f05Pyb29', 'a355412_mysql')
?>